BizVektor
==========
Free WordPress Theme for business
* * *
## Theme URI
http://bizvektor.com
## Description
BizVektor（ビズベクトル）テーマは管理画面からの設定のみで高品質なビジネスサイトを構築する事が出来ます。また、テーマ拡張プラグインによって新たに選択出来るデザインを増やす事が出来ます。
## Author
Vektor,Inc.
## Author URI
http://www.vektor-inc.co.jp/
## Version
0.11.1.1
## License
GNU General Public License