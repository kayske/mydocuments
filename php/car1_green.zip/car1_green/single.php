<?php get_header(); ?>
<div id="container">
  <div id="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div id="pankuzu">　<a href="<?php echo get_option('home'); ?>/">Home</a> &raquo; <?php the_category(', ') ?> &raquo; <strong><?php the_date('Y年m月d日'); ?> : <?php the_title(); ?></strong></div>
<h2><?php the_title();?></h2>
<?php the_content(); ?>

<div id="next">
<?php previous_post_link('←「%link」前の記事へ　'); ?>
<?php next_post_link('　次の記事へ「%link」→'); ?>
</div>

<?php endwhile; else: ?>

<?php endif; ?>
<?php comments_template( '', true ); ?>
</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
