      <div id="side">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ) : ?>
      <?php endif; ?>

</div></div>
  <!--/side end-->
