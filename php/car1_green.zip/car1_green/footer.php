<div id="footer">
Copyright(c) <?php the_time('Y') ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> All Rights Reserved.<br />
<a href="http://nikukyu-punch.com/" target="_blank">Template design by Nikukyu-Punch</a>　<a href="http://wp-site.biz/" target="_blank">wp-site.biz Themes</a>　<img src="<?php bloginfo('url'); ?>/wp-includes/images/rss.png" alt="RSS配信" width="14" height="14" /> <a href="<?php bloginfo('url'); ?>/feed/rss/">RSS</a></div>
<?php wp_footer(); ?>
</body>
</html>

