<?php
register_sidebar(array(
'before_widget' => '',
'after_widget' => '',
'before_title' => '<h3>',
'after_title' => '</h3>',
));
define( 'NO_HEADER_TEXT', true );
define('HEADER_IMAGE', '%s/images/car1.png');
define('HEADER_IMAGE_WIDTH', 900);
define('HEADER_IMAGE_HEIGHT', 300);
add_custom_image_header( $header_callback, $admin_header_callback );
add_custom_background();
?>
<?php add_theme_support( 'menus' ); ?>
