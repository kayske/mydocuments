<?php get_header(); ?>
<div id="container">
  <div id="main">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
 <div id="pankuzu">　<a href="<?php echo get_option('home'); ?>/">Home</a> &raquo; <strong><?php the_title(); ?></strong></div>  
<h2><?php the_title();?></h2>
<?php the_content(); ?>

<?php endwhile; else: ?>
<?php endif; ?>

</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
