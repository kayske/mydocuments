This resource has been created by elemis for http://elemisfreebies.com


TERMS OF USE:

All royalty free stock patterns, textures, design elements, themes and other design resources on this website are free for use in both personal and commercial projects.

You are allowed to use all PSD templates for both personal and commercial projects, unless you see “Free for only personal use” notice on the item page.

You may freely use them in software programs, iPhone skins, scrapbooking kits, web templates, Themeforest themes, websites, print on demand sites such as Zazzle, blogs, etc.

You may redistribute them within projects such as those listed above, but not by themselves as is.

If you use/modify the resources in your projects, we’d appreciate a linkback to the resource page. (Please don’t link directly to the .zip files, link to the resource page.)


-elemis
Visit our portfolio: http://elemisfreebies.com/portfolio

